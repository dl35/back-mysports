-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Hôte : mysql
-- Généré le : dim. 30 jan. 2022 à 13:06
-- Version du serveur : 5.6.40
-- Version de PHP : 7.4.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `product`
--


--
-- Déchargement des données de la table `user`
--

INSERT INTO `user` (`id`, `prenom`, `nom`, `email`, `passwd`, `adresse`, `ville`, `role`, `cp`) VALUES
(1, 'valentin', 'Andersen', 'valentin.andersen@gmail.com', '13ma', '9640 denny street', 'Marseille', 'ADMIN', 13000),
(2, 'pauline', 'Alighieri', 'pauline.alighieri@gmail.com', '35re', '4266 cork street', 'Rennes', 'USER', 35000),
(3, 'clementine', 'Austen', 'clementine.austen@gmail.com', '75pa', '4290 lovers ln', 'Paris', 'USER', 75000),
(4, 'lucas', 'Beckett', 'lucas.beckett@gmail.com', '69ly', '4605 st. john road', 'Lyon', 'USER', 69000),
(5, 'denis', 'Boccaccio', 'denis.boccaccio@gmail.com', '67st', '7013 36th ave', 'Strasbourg', 'USER', 67000),
(6, 'annie', 'Borges', 'annie.borges@gmail.com', '29br', '8151 necatibey cd', 'Brest', 'USER', 29000);


--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
